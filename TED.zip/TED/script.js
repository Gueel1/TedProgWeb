function mostrarEscolhas() {
  // Captura todas as checkboxes marcadas de entrada, pratoPrincipal e sobremesa
  const checkboxes = document.querySelectorAll(
    'input[type="checkbox"]:checked'
  );
  const escolhas = [];

  checkboxes.forEach((checkbox) => {
    const label = checkbox.nextElementSibling;
    const valor = checkbox.value;
    const imagem = label.querySelector("img")
      ? label.querySelector("img").src
      : "";

    escolhas.push({ valor, imagem });
  });

  // Armazena as escolhas no localStorage
  localStorage.setItem("escolhas", JSON.stringify(escolhas));

  // Redireciona para a página escolhas.html
  window.location.href = "escolhas.html";
}
// Recupera as escolhas do localStorage
const escolhas = JSON.parse(localStorage.getItem("escolhas"));

const escolhasList = document.getElementById("escolhasList");

if (escolhas && escolhas.length > 0) {
  escolhas.forEach((escolha) => {
    const li = document.createElement("li");
    const img = document.createElement("img");
    img.src = escolha.imagem;
    li.textContent = escolha.valor;
    li.appendChild(img);
    escolhasList.appendChild(li);
  });
} else {
  escolhasList.innerHTML = "<p>Nenhuma escolha feita.</p>";
}
function voltarParaMenu() {
  window.location.href = "index.html";
}
